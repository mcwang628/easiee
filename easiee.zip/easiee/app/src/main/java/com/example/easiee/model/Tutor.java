package com.example.easiee.model;

public class Tutor extends User {
    Tutor(String name, String userId, String password, boolean accountState, String type) {
        super(name, userId, password, accountState, type);
    }

    private String rate;

}
