package com.example.easiee;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.view.View;

public class RegisterActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.forget_password);


       /* Button backButton = findViewById(R.id.backButton);
        Button submitButton = findViewById(R.id.submitButton);
        final Intent mainMenu = new Intent(this, MainActivity.class);
        final Intent mainPage = new Intent(this, UserMainPage.class);
        backButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(mainMenu);
            }
        });
        submitButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(tu);
            }
        });*/
    }
}
