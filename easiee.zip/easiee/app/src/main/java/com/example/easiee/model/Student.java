package com.example.easiee.model;

public class Student extends User {
    Student(String name, String userId, String password, boolean accountState, String type) {
        super(name, userId, password, accountState, type);
    }
    private String grade;
}
