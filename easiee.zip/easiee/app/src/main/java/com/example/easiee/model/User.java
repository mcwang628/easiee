package com.example.easiee.model;

public class User {
    private String name;
    private final String userId;
    private String password;
    private String type;
    private boolean accountState;
    User(String name, String userId, String password, boolean accountState, String type) {
        this.name = name;
        this.userId = userId;
        this.password = password;
        this.accountState = accountState;
        this.type = type;

    }
    String getName() {
        return name;
    }

    public boolean getAccountState() {
        return accountState;
    }

    public String getUserId() {
        return userId;
    }
    public String getPassword() {
        return password;
    }
    void setName(String name){this.name = name;}
    void setPassword(String pass){this.password = password;}
    void setType(String type){this.type = type;}
    void setAccountState(boolean ban){this.accountState = ban;}


}
